const textForRole = (roles, textLines) => {
    let array = textLines.split("\n");
    let result;
    let replik = '';
    let finish = '';

    for (let i = 0; i < 4; i++) {
        let roleNumb = 0;
        replik = '';

        for (let j = 0; j < 7; j++) {
            roleNumb += 1;
            result = "\n" + `${roles[i]}:` + "\n";

            if (array[j].includes(roles[i], 0)) {
                let index = array[j].indexOf(":");
                array[j] = `${roleNumb}) ` + array[j].slice(index + 2);
                replik += array[j] + "\n";
            }
        }
        finish += result + replik;
    }
    let fin = finish.substr(1);
    return fin;
}


module.exports = textForRole;

