const findVowels = (str) => {
     if(typeof str !== 'string') {
    return 'Passed argument is not a string';
    
  } else if (str === '') {
    return 'String is empty';

  } else {
    const regExp = /[aeiouy]/gi;
    const array = str.match(regExp);
    return array === null ? 'String does not contain vowels' : array.length;
  }
};

module.exports = findVowels;
