const evenNumbersInArray = (array) => {
    if(!Array.isArray(array) || array.length === 0) {

      return "Passed argument is not an array or empty";

    } else {
        const modifiedArray = array.filter(el => el % 2 == 0);

        if(modifiedArray.length === 0) {

            return "Passed array does not contain even numbers";

        } else {
            
            return modifiedArray;
        }
    } 
};

module.exports = evenNumbersInArray;

