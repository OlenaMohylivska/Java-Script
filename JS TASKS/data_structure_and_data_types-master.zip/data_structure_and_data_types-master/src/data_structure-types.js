const validateTitle = (arg) => {
    if(typeof arg !== 'string') {
        return 'Incorrect input data';

    } else if(arg.length < 2 || arg.length > 20) {
        return 'INVALID';

    } else if(arg[0] === (arg[0].toLowerCase())) {
    return 'INVALID';

    } else {
      return 'VALID';
  }
}

const sum = (value1, value2) => {
  if(typeof value1 === 'number') {
        value2 = Number(value2);
        if(value1 % 3 === 0 && value1 % 15 === 0) {
            value1 *= -1;
        }
    } else {
        value1 = Number(value1);
        if(value2 % 3 === 0 && value2 % 15 === 0) {
            value2 *= -1; 
        }
    }
    return value1 + value2;
};

module.exports = {
  validateTitle,
  sum,
};
