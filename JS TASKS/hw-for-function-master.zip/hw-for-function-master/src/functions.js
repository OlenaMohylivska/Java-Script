function isBigger(a, b) {
  return a > b;
}

function isSmaller(a, b) {
  return isBigger(a, b) === false;
}

function getMin(...numbers) {
  return Math.min(...numbers);
}

function makeNumber(string) {
  let newString = '';
    for( let i = 0; i < string.length; i++) {
        let el = string[i];

        if(el === '0' || parseInt(el)) {
            newString += el;   
        } 
    }
    return newString;
}

function countNumbers(string) {
  var numbers = makeNumber(string);
    let obj = {};

    for (let i = 0; i < numbers.length; i++) {
        let el = numbers[i];
        if (!obj.hasOwnProperty(el)) { 

           let j = 0;
            for (let i = 0; i < numbers.length; i++) {
                let currentEl = numbers[i];
                
                if (el === currentEl) {
                    j++;
                }
                
            }
            obj[el] = j;
        }
    }
    return obj;
}

function pipe(number, ...functions) {
  let numb = number;
    functions.forEach(func => {
      numb = func(numb);
    })
    return numb;
}

function isLeapYear(date) {
   const myDate = new Date(date);
    const year = myDate.getFullYear();
    if(!year) {
        return 'Invalid Date';

    } else if(year === 2200) {
        return `${year} is not a leap year`;
        
    } else if(year % 4 === 0) {
        return `${year} is a leap year`;
    
    } else {
        return `${year} is not a leap year`;
    }
}


module.exports = {
  isBigger,
  isSmaller,
  makeNumber,
  countNumbers,
  getMin,
  pipe,
  isLeapYear,
};
