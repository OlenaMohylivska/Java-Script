const cache = (func) => {
    let cache = new Map();
    return function(x, y) {
      if (cache.has(x + y)) {    
        return cache.get(x + y); 
      }

      let result = func(x, y); 

      cache.set(x + y, result); 
      return result;
    };
}


const forwardBackwardSteps = {
    counter: 0,
    forward: function() {
        this.counter += 1;
        return this;
    },
    backward: function() {
        this.counter -= 1;
        return this;
    },
    revealStep: function() {
        console.log(this.counter);
        return this;
    }
};


const applyAll = (func, ...args) => {
    return func.call(null, ...args); 
}


const sum = (...args) => {
    let summ = 0;
    for(let i = 0; i < args.length; i++) {
        summ += args[i];
    }
    return summ;
}

const mul = (...args) => {
    let mull = 1;
    for(let i = 0; i < args.length; i++) {
        mull *= args[i];
    }
    return mull;
}

module.exports = {cache, forwardBackwardSteps, applyAll, sum, mul}
