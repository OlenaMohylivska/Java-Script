const detectPalindrome = (str) => {
      if(typeof str !== 'string') {
    return 'Passed argument is not a string';

  } else if (str === '') {
    return 'String is empty';

  } else {
     let newStr = '';

    for(let i = 0; i <= str.length; i++) {
      newStr += str.charAt(str.length - i).toLowerCase();
    }

    return newStr === str.toLowerCase() ? 'This string is palindrome!' : 'This string is not a palindrome!';
  }
};

module.exports = detectPalindrome;
