const snakeArray = (snakeStart) => {
  let arr = Array.from(Array(6), () => new Array());
  let num = snakeStart;

  for (let i = 0; i < 7; i++) { 
    arr[0].push(num++);
  }

  for (let i = 1; i < 6; i++) {
    arr[i].push(num++);
  } 

  for (let i = 1; i < 7; i++) { 
    arr[5].unshift(num++);
  }

  for (let i = 4; i > 0; i--) { 
    arr[i].unshift(num++);
  }

  for (let i = 0; i < 5; i++) {  
    arr[1].splice(-1, 0, num++);
  }

  for (let i = 2; i < 5; i++) {
    arr[i].splice(1, 0, num++);
  }

  for (let i = 0; i < 4; i++) {
    arr[4].splice(1, 0, num++);
  }

  for (let i = 3; i > 1; i--) {
    arr[i].splice(-2, 0, num++);
  }

  for (let i = 0; i < 3; i++) { 
    arr[2].splice(-2, 0, num++);
  }

  for (let i = 0; i < 3; i++) {
    arr[3].splice(2, 0, num++);
  }
    return arr;
}

module.exports = snakeArray;
