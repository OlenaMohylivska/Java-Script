function convert(...args) {
  let myArray = [];
  for (let element of args) {
    if (typeof element === 'string') {
      myArray.push(+element);
    } else {
      myArray.push('' + element);
    }
  }
  return myArray;
}

const executeforEach = (arr, func) => {
  const array = arr.slice();
  for (let i = 0; i < array.length; i++) {
    array[i] = func(array[i])
  }
};

const mapArray = (arr, funct) => {
  let array = [];
  executeforEach(arr, element => array.push(parseInt(element)));
  for (let i = 0; i < arr.length; i++) {
    array[i] = funct(array[i]);
  }
  return array;
};

const filterArray = (array, func) => {
  
  let finishedArray = [];
  executeforEach(array, element => {
    if (func(element)) {
      finishedArray.push(element)
    }
  });
  
  return finishedArray;
}


const flipOver = (str) => {
  let newStr = '';
  for (let i = str.length - 1; i >= 0; i--) {
    newStr = newStr + str[i];
  }
  return newStr;
};

const makeListFromRange = (array) => {
  let newArray = [];
  if (array[0] < array[1]) {
    for (let i = array[0]; i <= array[1]; i++) {
      newArray.push(i);
    }
  } else if (array.length == 1) {
    return array;
  } else {
    for (let i = array[0]; i >= array[1]; i--) {
      newArray.push(i);
    }
  }
  return newArray;
};

const getArrayOfKeys = (array, key) => {
  const newArray = [...array];
  const secondArray = [];
  executeforEach(newArray, el => secondArray.push(el[key]));
  return secondArray;
};

const substitute = (array) => {

  let result = array.map(el => {
      if(el < 30) {
      el = '*';
      return el;
      
      } else {
          return el;
      }
  });

  return result;
};

const getPastDay = (date, day) => {
  const pastDate = new Date(date);
  pastDate.setDate(date.getDate() - day);
  return pastDate.getDate() ;
};

const formatDate = (date) => {
  let someDate = new Date(date);
  let year = someDate.getFullYear();
  let month = someDate.getMonth() + 1;
  let dayOfMonth = someDate.getDate();
  let hour = someDate.getHours();
  let minutes = someDate.getMinutes();
  month = month < 10 ? '0' + month : month;
  dayOfMonth = dayOfMonth < 10 ? '0' + dayOfMonth : dayOfMonth;
  hour = hour < 10 ? '0' + hour : hour;
  minutes = minutes < 10 ? '0' + minutes : minutes;
  let result = `${year}/${month}/${dayOfMonth} ${hour}:${minutes}`;
  return result;
};

module.exports = {
  convert,
  executeforEach,
  mapArray,
  filterArray,
  flipOver,
  makeListFromRange,
  getArrayOfKeys,
  substitute,
  getPastDay,
  formatDate,
};
