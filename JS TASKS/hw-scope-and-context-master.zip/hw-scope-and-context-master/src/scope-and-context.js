function Fighter(ob) {

	const name = ob.name;
	const damage = ob.damage;
	let hp = ob.hp;
	const strength = ob.strength;
	const agility = ob.agility;
	let wins = 0;
	let losses = 0;

	return {
		getName() {
			return name;
		},
		getDamage() {
			return damage;
		},
		getAgility() {
			return agility;
		},
		getHealth() {
			return hp;
		},
		getStrength() {
			return strength;
		},
		attack(defender) {
			const isSuccessful = Math.floor(Math.random() * (100 - 0 + 1)) + 0;
			let sum = defender.getAgility() + defender.getStrength();

			if (sum > isSuccessful) {
				console.log(`${this.getName()} attack missed`);
			} else {
				console.log(`${this.getName()} makes ${this.getDamage()} damage to ${defender.getName()}`);
				defender.dealDamage(damage);
			}
		},
		logCombatHistory() {
			console.log(`Name:${this.getName()},Wins:${wins},Losses:${losses}`);
		},
		heal(h) {
			hp += h;
		},
		dealDamage(damage) {
			hp -= damage;
			return hp < 0 ? hp = 0 : hp;
		},
		addWin() {
			wins += 1;
		},
		addLoss() {
			losses += 1;
		},
	}

}

const battle = function (fighter1, fighter2) {

	if (fighter2.getHealth() === 0) {
		console.log(`${fighter2.getName()} is dead`);
		return 0;

	} else if (fighter1.getHealth() === 0) {
		console.log(`${fighter1.getName()} is dead`);
		return 0;
	}

	while (fighter2.getHealth() > 0 && fighter1.getHealth() > 0) {
		fighter1.attack(fighter2);
		fighter2.attack(fighter1);
	}

	if (fighter2.getHealth() === 0 && fighter1.getHealth() === 0) {
		console.log(`${fighter1.getName()} is dead`);
		console.log(`${fighter2.getName()} is dead`);
		return 0;

	}
	if (fighter2.getHealth() === 0) {
		console.log(`${fighter1.getName()} has won!`);
		fighter1.addWin();
		fighter2.addLoss();
	
		return fighter2;

	} else if (fighter1.getHealth() === 0) {
		console.log(`${fighter2.getName()} has won!`);
		fighter2.addWin();
		fighter1.addLoss();
		return fighter1;
	}
}

module.exports = { Fighter, battle};
