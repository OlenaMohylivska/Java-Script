const chai = require('chai');


global.expect = chai.expect;