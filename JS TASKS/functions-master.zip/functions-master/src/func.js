const getSum = (str1, str2) => {
   if(typeof str1 !== 'string' && typeof str2 !== 'string') {
        return false; 

    } else if (/\D/.test(str1) && /\D/.test(str2)) {
        return false;

    } else {
        return String(Number(str1) + Number(str2));
    } 
}

const getQuantityPostsByAuthor = (listOfPosts, authorName) => {
  let post = 0;
    let comm = 0;

    listOfPosts.forEach(el => {
        if(el.author === authorName) {
            post++;
        }
        let commArray = el.comments;
        if(!commArray) {
            return;
        }
        
        commArray.forEach(el => {
         if(el.author === authorName) {
            comm++; 
         }  
        })
    })

    return `Post:${post},comments:${comm}`;
}

const tickets=(people)=> {
  let secondSum;
        let current = Number(people[0]);
        for(let i = 0; i < people.length-1;) {
            
            secondSum = Number(people[++i]);
        

        if(people[0] > 25) {
            return 'NO';

        } else if(secondSum === 25) {
            current += secondSum;
            
        } else if(secondSum === 50) {
            current -= 25;
                if(current < -1) {
                    return 'NO' 
                } 
            current += 50;
                   
            

        } else if(secondSum === 100) {
            current -= 75;
                if(current < -1) {
                    return 'NO';
                }
                current += 100;
        }     
    }
    return 'YES';
}


module.exports = {getSum, getQuantityPostsByAuthor, tickets};
